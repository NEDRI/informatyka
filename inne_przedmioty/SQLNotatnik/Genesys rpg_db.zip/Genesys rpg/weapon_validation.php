<?php
//making sample table for items
function maketableitem(){
	echo"<table border=1>"
	."<tr>"
		."<th>Name</th>"
		."<th>Damage</th>"
		."<th>Crit</th>"
		."<th>Encumbrance</th>"
		."<th>Hard_Points</th>"
		."<th>Rarity</th>"
		."<th>Skill_ID</th>"
		."<th>Range_id</th>"
		."<th>Price</th>"
		."<th>Item_Id</th>"
	."</tr>"
	."<tr>";	
}
//ending sample table
function endtable(){
	echo"</tr></table>";
}
//making sample table for specials
function maketablespecials(){
	echo"<table border=1>"
	."<tr>"
		."<th>Item_Id</th>"
		."<th>Special_Id</th>"
		."<th>Rank</th>"
	."</tr>"
	."<tr>";	
	
}
//checking if specials are selected and combining them into array
function checkspecial($id,$rank){
	if($id==0){
		return false;
	}
	$special[0]=$id;
	$special[1]=$rank;
		return $special;
}

//drawing sample table for specials
function drawtablespecial($id,$special){ 
	if($special){
		echo "</tr><tr>"
				."<th>"
					.$id
				."</th>"
				."<th>"
					.$special[0]
				."</th>"
				."<th>"
					.$special[1]
				."</th>";
		
		
	}
}

function insertweapon($name,$damage,$crit,$encum,$hp,$rarity,$skill,$range,$price){
	$db = new mysqli("localhost","root","","genesys");
	$sql = "INSERT INTO item "
	."(Name,Damage,Crit,Encumbrance,Hard_Points,Rarity,Skill_ID,Range_id,Price) "
	."VALUES "
	."(\"$name\",$damage,$crit,$encum,$hp,$rarity,$skill,$range,$price);";
	
	$db->query($sql);
	mysqli_close($db);
}
function selectnewweapon($name,$damage,$crit,$encum,$hp,$rarity,$skill,$range,$price){
	$db = new mysqli("localhost","root","","genesys");
	$sql = "SELECT Item_Id " 
	."FROM item "
	."WHERE "
	."Name = \"$name\" AND "
	."Damage = $damage AND "
	."Crit = $crit AND "
	."Encumbrance = $encum AND "
	."Hard_Points = $hp AND "
	."Rarity = $rarity AND "
	."Skill_ID = $skill AND "
	."Range_id = $range AND "
	."price = $price "
	."ORDER BY Item_Id ASC; ";
	
	$result = $db->query($sql);
	while($row=$result->fetch_assoc()){
		$id = $row["Item_Id"];
	}
	mysqli_close($db);
	if($id==NULL){
		return 0;
	}
	else{		
		return $id;
	}
}
function insertweaponspecials($id,$special){
	if($id>0 && $special){
		$db = new mysqli("localhost","root","","genesys");
		$sql="INSERT INTO items_specials(Item_ID,Special_Id,Rank) "
		."VALUES($id,$special[0],$special[1]) ";
		$db->query($sql);
		mysqli_close($db);
	}
}
if(isset($_POST["weapon_name"])){
	
	
#WEAPON NAME VALIDATION
	$weapon_name=ucwords($_POST["weapon_name"]);
	$weapon_name=trim(rtrim($weapon_name));
	
#WEAPON DAMAGE TO PRICE VALIDATION
	$weapon_damage = $_POST["Damage"];
	$weapon_crit = $_POST["Crit"];
	$weapon_encumbrance = $_POST["Encumbrance"];
	$weapon_hp = $_POST["HP"];
	$weapon_rarity = $_POST["Rarity"];
	$weapon_skill = $_POST["Skill"];
	$weapon_range = $_POST["Range"];
	$weapon_price = $_POST["Price"];

#INSERTING WEAPON INTO DATABASE
insertweapon($weapon_name,$weapon_damage,$weapon_crit,$weapon_encumbrance,$weapon_hp,$weapon_rarity,$weapon_skill,$weapon_range,$weapon_price);

#SELECTING ID OF THE WEAPON FROM DATABASE	
$weapon_id=selectnewweapon($weapon_name,$weapon_damage,$weapon_crit,$weapon_encumbrance,$weapon_hp,$weapon_rarity,$weapon_skill,$weapon_range,$weapon_price);
	
#GETTING SPECIALS INFO
	if(isset($_POST["special1"])){
		$special1 = checkspecial($_POST["special1"],$_POST["rank1"]);
	}
	else{$special1=false;}
	
	
	if(isset($_POST["special2"])){
		$special2 = checkspecial($_POST["special2"],$_POST["rank2"]);
	}
	else{$special2=false;}
	
	
	if(isset($_POST["special3"])){
		$special3 = checkspecial($_POST["special3"],$_POST["rank3"]);
	}
	else{$special3=false;}
	
	
	if(isset($_POST["special4"])){
		$special4 = checkspecial($_POST["special4"],$_POST["rank4"]);
	}
	else{$special4=false;}
	
#INSERTING SPECIALS
insertweaponspecials($weapon_id,$special1);
insertweaponspecials($weapon_id,$special2);
insertweaponspecials($weapon_id,$special3);
insertweaponspecials($weapon_id,$special4);


	
#SAMPLE TABLES	
	maketableitem();
	echo "<th>".$weapon_name."</th>";
	echo "<th>".$weapon_damage."</th>";
	echo "<th>".$weapon_crit."</th>";
	echo "<th>".$weapon_encumbrance."</th>";
	echo "<th>".$weapon_hp."</th>";
	echo "<th>".$weapon_rarity."</th>";
	echo "<th>".$weapon_skill."</th>";
	echo "<th>".$weapon_range."</th>";
	echo "<th>".$weapon_price."</th>";
	echo "<th>".$weapon_id."</th>";
	endtable();
	
	echo "<br>";
	
	maketablespecials();

	drawtablespecial($weapon_id,$special1);
	drawtablespecial($weapon_id,$special2);
	drawtablespecial($weapon_id,$special3);
	drawtablespecial($weapon_id,$special4);
	
	endtable();
	
	
	
	
	
	
	
	
	
	
	echo "<br><br><br><br>";

	echo "You have done it!";
	$_POST=array();
	header("Location:index.php?add=1");
	die();
}


?>
