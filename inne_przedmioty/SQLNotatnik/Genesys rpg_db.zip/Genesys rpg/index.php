<html>
<?php
	include 'functions.php';
	?>
	<head>
		<title> Genesys RPG </title>
		<link rel="stylesheet" href="styles.css">
	</head>
<body>
<div class="mylinks" align="center">
<a href="index.php">Strona Główna</a>
<a href="index.php?show_all">Pokaż Wszystkie Bronie</a>
<a href="index.php?weapon_search">Wyszukiwarka</a>
<a href="index.php?add">Dodaj</a>
</div>
<hr>


		<?php
			if(isset($_GET["show_all"])){
				include "show_all.php";
			}
			if(isset($_GET["add"])){
				include "add.php";
			}
			if(isset($_GET["weapon_search"])){
				include "weapon_search.php";
			}
			

			
		?>
</body>

</html>
