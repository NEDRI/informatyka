<div class="wholewitdh">
<form method="POST" action="index.php?weapon_search">
	<div class="centerme" align="center">
		<input type="reset" name="reset" value="Resetuj">
		<?php
			if(isset($_POST["reset"])){
				header("Location:index.php?add");
			}
		?>

	</div>

	<div class="weapon">
		<div class="tittleBox">
			<div class="text" align="center">
<input type="text" name="weapon_name" placeholder="Nazwa" 
style="background:transparent; height:50px; 
width:300px; text-align:center; letter-spacing:3px;
text-shadow:2px 2px 4px black; color:#f5f1ed;" 
 >
			</div>
		</div>
		<br>
		<div class="box" align="center">
		
<select name="Damage"  
style="width:50px; height:40px; text-align:center; 
margin-top:8px; font-weight:bold;">
<option value="-" selected > </option>
	<?php
	for($x = -12; $x<=12; $x++)
	{
		echo "<option value=$x";
		if($x<0){
			echo">+".abs($x)."</option>";
		}
		else{
			echo">$x</option>";
		}
	}
	
	?>
	
</select>
		</div>
		<div class="box" align="center">
<select name="Crit" 
style="width:50px; height:40px; text-align:center;
margin-top:8px; font-weight:bold;">
<option value="-" selected > </option>
	<?php
	for($x=1; $x<=5; $x++)
	{
		echo "<option value=$x";
			echo">$x</option>";
	}
	
	?>
</select>	
	
		</div>
		<div class="box" align="center">

<select name="Encumbrance" 
style="width:50px; height:40px; text-align:center;
margin-top:8px; font-weight:bold;">
<option value="-" selected > </option>
	<?php
	for($x=1; $x<=12; $x++)
	{
		echo "<option value=$x";
			echo">$x</option>";
	}
	
	?>
</select>

		</div>
		<div class="box" align="center">

<select name="HP" 
style="width:50px; height:40px; text-align:center;
margin-top:8px; font-weight:bold;">
<option value="-" selected > </option>
	<?php
	for($x=0; $x<=4; $x++)
	{
		echo "<option value=$x";
		echo">$x</option>";
	}
	
	?>
</select>

		</div>
		<div class="box" align="center">

<select name="Rarity" 
style="width:50px; height:40px; text-align:center;
margin-top:8px; font-weight:bold;">
<option value="-" selected > </option>
	<?php
	for($x=0; $x<=10; $x++)
	{
		echo "<option value=$x";
			echo">$x</option>";
	}
	
	?>
</select>

		</div>
		<br>
		<div class="smallbox">
			<table>
				<tr>
					<th>Damage</th>
					<th>Crit</th>
					<th>Encumbrance</th>
					<th>Hard Points</th>
					<th>Rarity</th>
				</tr>
			</table>
		</div>
		<div class="jump"><hr></div>
		<div class="jump"></div>
			<div class="infobox1" align="center">
				<br>SKILL
			</div>
			<div class="infobox" align="center">
				<br>RANGE
			</div>
			<div class="infobox4" align="center">
				<br>PRICE
			</div>
			
			
			<div class="infobox5">
				<div class="infotext" align="center">
				
<select name="Skill" 
style="width:110px; height:30px; text-align:center;
margin-top:2px; font-weight:bold; background:transparent; font-size:12px;">
	<option value=0 selected > </option>
	<?php
	
	$db=new mysqli("localhost","root","","genesys");
	$sql="SELECT Skill_ID as skill_id,Name as skill_name FROM skill";
	$result = $db->query($sql);
	mysqli_close($db);
	
	while($row = $result->fetch_assoc()){
			echo "<option value="
			.$row["skill_id"]
			.">"
			.$row["skill_name"]
			."</option>";
	}
	
	
	?>
</select>
				</div>
			</div>
			<div class="infobox2">
				<div class="infotext" align="center">

<select name="Range" 
style="width:110px; height:30px; text-align:center;
margin-top:2px; font-weight:bold; background:transparent; font-size:12px;">
	<option value=0 selected > </option>

<?php
	$db=new mysqli("localhost","root","","genesys");
	$sql="SELECT Range_ID as range_id,Name as weapon_name FROM weapon_range";
	$result = $db->query($sql);
	mysqli_close($db);
	while($row = $result->fetch_assoc()){
			echo "<option value="
			.$row["range_id"]
			.">"
			.$row["weapon_name"]
			."</option>";
	}
?>
				
</select>
				</div>
			</div>
			<div class="infobox8">
				<div class="infotext" align="center">
<input type="number" name="Price" min=0 
style="width:110px; height:30px; text-align:center;
margin-top:2px; font-weight:bold; background:transparent; font-size:12px;">
				</div>
			</div>
			
		<div class="jump"></div>
		
		<div class="specialbox" align="center">
			<div class="jump"></div><a>SPECIAL</a>
		</div>

		<div class="specialbox1">
			<div class="lastbit" align="center">
<?php
function list_select_specials(){
	$db=new mysqli("localhost","root","","genesys");
	$sql="SELECT * FROM special";
	$result = $db->query($sql);
	while($row=$result->fetch_assoc()){
		echo "<option value="
		.$row["Special_Id"]
		.">"
		.$row["Name"];
		
		if($row["Active"]) echo "*";
		
		echo "</option>";
	}
}
?>
<select name = "special1" 
style="width:110px; height:25px; text-align:center;
margin-top:5px; font-weight:bold; background:transparent; font-size:12px;">
<option value=0  selected></option>
<?php
list_select_specials();
?>

</select>

<a> </a>
<select name = "special2" 
style="width:110px; height:22px; text-align:center;
margin-top:5px; font-weight:bold; background:transparent; font-size:12px;">
<option value=0  selected></option>
<?php
list_select_specials();
?>

</select>


<br>	

<select name = "special3" 
style="width:110px; height:22px; text-align:center;
margin-top:5px; font-weight:bold; background:transparent; font-size:12px;">
<option value=0  selected></option>
<?php
list_select_specials();
?>

</select>

<a> </a>
<select name = "special4" 
style="width:110px; height:22px; text-align:center;
margin-top:5px; font-weight:bold; background:transparent; font-size:12px;">
<option value=0  selected></option>
<?php
list_select_specials();
?>

</select>

	
			</div>
		</div>
	</div>
	<div class="left" align="center">
		<input type="submit" value="Szukaj" name="Search">
	</div>
</form>
</div>
<div class="wholewitdh">
<?php
if(isset($_POST["Search"])){
	
	include "search_functions.php";
	
	$sql = "SELECT DISTINCT item.item_id AS id FROM item "
	."LEFT JOIN items_specials ON item.item_id = items_specials.Item_ID "
	."WHERE 1";
	$sql = $sql.getWeaponItemSearchPostValues();
	//echo "<br><br>".$sql;
	$sql =$sql." ORDER BY item.Name ASC;";
	
	$db = new mysqli("localhost","root","","genesys");
	$result = $db->query($sql);
	mysqli_close($db);
	
	while($row=$result->fetch_assoc()){
		drawWeaponCard($row["id"]);
	}
}

?>
</div>