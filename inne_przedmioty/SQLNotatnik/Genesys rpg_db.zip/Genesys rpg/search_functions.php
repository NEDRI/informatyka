<?php
	function searchForWeaponName($name){
		if($name==""){
			return "";
		}
		$sql =" AND LOWER(Name) LIKE LOWER(\"%"
		.$name
		."%\")";
		return $sql;
	}
	function searchForWeaponDamage($value){
		$sql="";
		if($value=="-"){
			return $sql;
		}
		if($value<0){
			$sql =" AND Damage <= $value";
		}
		else{
			$sql =" AND Damage >= $value";
		}
		return $sql;
	}
	function searchForWeaponCrit($value){
		$sql="";
		if($value=="-"){
			return $sql;
		}
		$sql =" AND Crit <= $value";
		return $sql;
	}
	function searchForWeaponEncum($value){
		$sql="";
		if($value=="-"){
			return $sql;
		}
		$sql =" AND Encumbrance <= $value";
		return $sql;
	}
function searchForWeaponHP($value){
		$sql="";
		if($value=="-"){
			return $sql;
		}
		$sql =" AND Hard_Points >= $value";
		return $sql;
	}
function searchForWeaponRarity($value){
		$sql="";
		if($value=="-"){
			return $sql;
		}
		$sql =" AND Rarity <= $value";
		return $sql;
	}
function searchForWeaponSkill($value){
		$sql="";
		if($value=="-"||$value==0){
			return $sql;
		}
		$sql =" AND Skill_ID = $value";
		return $sql;
	}
function searchForWeaponRange($value){
		$sql="";
		if($value=="-"||$value==0){
			return $sql;
		}
		$sql =" AND Range_id >= $value";
		return $sql;
	}
function searchForWeaponPrice($value){
		$sql="";
		if($value=="-"){
			return $sql;
		}
		if(!($value>0)){
			$sql ="";
		}
		else{
			$sql =" AND Price <= $value";
		}
		
		return $sql;
	}
function searchForWeaponSpecial($value){
	if($value>0){
		$sql =" AND items_specials.Special_Id = $value";
	}
	else{
		$sql ="";
	}
	return $sql;
}
function getWeaponItemSearchPostValues(){
	$sql="";
	if(isset($_POST["weapon_name"])){
		$sql=$sql.searchForWeaponName($_POST["weapon_name"]);
	}
	if(isset($_POST["Damage"])){
		$sql=$sql.searchForWeaponDamage($_POST["Damage"]);
	}
	if(isset($_POST["Crit"])){
		$sql=$sql.searchForWeaponCrit($_POST["Crit"]);
	}
	if(isset($_POST["Encumbrance"])){
		$sql=$sql.searchForWeaponEncum($_POST["Encumbrance"]);
	}
	if(isset($_POST["HP"])){
		$sql=$sql.searchForWeaponHP($_POST["HP"]);
	}
	if(isset($_POST["Rarity"])){
		$sql=$sql.searchForWeaponRarity($_POST["Rarity"]);
	}
	if(isset($_POST["Skill"])){
		$sql=$sql.searchForWeaponSkill($_POST["Skill"]);
	}
	if(isset($_POST["Range"])){
		$sql=$sql.searchForWeaponRange($_POST["Range"]);
	}
	if(isset($_POST["Price"])){
		$sql=$sql.searchForWeaponPrice($_POST["Price"]);
	}
	if(isset($_POST["special1"])){
		$sql=$sql.searchForWeaponSpecial($_POST["special1"]);
	}
	if(isset($_POST["special2"])){
		$sql=$sql.searchForWeaponSpecial($_POST["special2"]);
	}
	if(isset($_POST["special3"])){
		$sql=$sql.searchForWeaponSpecial($_POST["special3"]);
	}
	if(isset($_POST["special4"])){
		$sql=$sql.searchForWeaponSpecial($_POST["special4"]);
	}
	return $sql;
}
?>