<html>
	<head>
		<title> Genesys RPG </title>
		<link rel="stylesheet" href="styles.css">
	</head>
<body>



<div class="weapon">
	<div class="tittleBox">
		<div class="text">Name</div>
	</div>
	<br>
	<div class="box">
		<div class="value">
			<div class="valueborder">
				4
			</div>
		</div>
	</div>
	<div class="box">
		<div class="value">
			<div class="valueborder">
				3
			</div>
		</div>
	</div>
	<div class="box">
		<div class="value">
			<div class="valueborder">
				12
			</div>
		</div>
	</div>
	<div class="box">
		<div class="value">
			<div class="valueborder">
				12
			</div>
		</div>
	</div>
	<div class="box">
		<div class="value">
			<div class="valueborder">
				12
			</div>
		</div>
	</div>
	<br>
	<div class="smallbox">
		<table>
			<tr>
				<th>Damage</th>
				<th>Crit</th>
				<th>Encumbrance</th>
				<th>Hard Points</th>
				<th>Rarity</th>
			</tr>
		</table>
	</div>
	<div class="jump"><hr></div>
	<div class="jump"></div>
		<div class="infobox1" align="center">
			<br>SKILL
		</div>
		<div class="infobox" align="center">
			<br>RANGE
		</div>
		<div class="infobox4" align="center">
			<br>PRICE
		</div>
		
		
		<div class="infobox5">
			<div class="infotext" align="center">
				<p class="itext">abc</p>
			</div>
		</div>
		<div class="infobox2">
			<div class="infotext" align="center">
				<p class="itext">abc</p>
			</div>
		</div>
		<div class="infobox8">
			<div class="infotext" align="center">
				<p class="itext">abc</p>
			</div>
		</div>
		
	<div class="jump"></div>
	
	<div class="specialbox" align="center">
		<div class="jump"></div><a>SPECIAL</a>
	</div>

	<div class="specialbox1">
		<div class="lastbit">
			
		</div>
	</div>
</div>
