<?php
		function getname($id=1){
			$db = new mysqli("localhost","root","","genesys");
			$name = "NON-EXIST";
			
			$sql_getname="SELECT name FROM item WHERE Item_Id = $id";
			$result = $db->query($sql_getname);
			while($row=$result->fetch_assoc()){
				$name = $row["name"];
			}
			mysqli_close($db);
			return $name;
		}
			
		function getcharacteristics($id=1){
			$db = new mysqli("localhost","root","","genesys");
			for($x=0;$x<5;$x++){
				$characteristic[$x] = "N";
			}
			
			
			$sql_getname="SELECT Damage,Crit,Encumbrance,Hard_Points,Rarity FROM item WHERE Item_Id = $id";
			$result = $db->query($sql_getname);
			while($row=$result->fetch_assoc()){
				
				$characteristic[1] = $row["Crit"];
				$characteristic[2] = $row["Encumbrance"];
				$characteristic[3] = $row["Hard_Points"];
				$characteristic[4] = $row["Rarity"];
				
				if($row["Damage"]>=0) {
					$characteristic[0]=$row["Damage"];
				}
				else{
					$characteristic[0]="+".abs($row["Damage"]);
				}
			}
			mysqli_close($db);
			return $characteristic;		
		}

			function srp($id=1){
				$db = new mysqli("localhost","root","","genesys");
				$srp[0]="NON-EXIST";
				$srp[1]="NON-EXIST";
				$srp[2]="NON-EXIST";
				
				$sql = "SELECT skill.Name as skill_name, weapon_range.name as range_name, item.Price FROM item 
						INNER JOIN skill ON item.Skill_ID = skill.Skill_ID 
						INNER JOIN weapon_range ON weapon_range.Range_Id = item.Range_id
						WHERE item.Item_Id = $id;
						";
				$result = $db->query($sql);
				while($row=$result->fetch_assoc()){
					$srp[0]=$row["skill_name"];
					$srp[1]=$row["range_name"];
					$srp[2]=$row["Price"];
				}
				mysqli_close($db);
				return $srp;
			}
			
			function specials($id=1){
				$db = new mysqli("localhost","root","","genesys");
				$specials[0]="";
				$ranks[0]="";
				$actives[0]="";
				
				$sql = "SELECT special.name, items_specials.Rank, special.Active FROM `items_specials`
						INNER JOIN special ON items_specials.Special_Id = special.Special_Id
						WHERE items_specials.Item_ID = $id;";
						
				$result = $db->query($sql);
				$x = 0;
				while($row=$result->fetch_assoc()){
					
					
					if($row["Rank"]>0){
						$ranks[$x]=$row["Rank"];
					}
					else{
						$ranks[$x]="";
					}
					if($row["Active"]){
						$specials[$x]="<i>".$row["name"]."</i>";
					}
					else{
						$specials[$x]=$row["name"];
					}
					
					$x++;
				}
				mysqli_close($db);
				
				for($x=0;$x<count($specials);$x++){
					$spec[$x][0]=$specials[$x];
					$spec[$x][1]=$ranks[$x];
				}
				
				return $spec;				
				
			}
			
			function drawWeaponCard($id=1){
				echo'<div class="weapon">'.
					'	<div class="tittleBox">'.
					'		<div class="text">';
				echo getname($id);
				echo'</div></div><br>';
				
				$ch = getcharacteristics($id);
				for($xx=0;$xx<5;$xx++){
					echo'<div class="box">'.
						'	<div class="value">'.
						'		<div class="valueborder">';
					echo $ch[$xx];
					echo "</div></div></div>";
				}
				echo "<br>";
				$srp = srp($id);
				echo '	<div class="smallbox">'.
					'		<table>'.
					'			<tr>'.
					'				<th>Damage</th>'.
					'				<th>Crit</th>'.
					'				<th>Encumbrance</th>'.
					'				<th>Hard Points</th>'.
					'				<th>Rarity</th>'.
					'			</tr>'.
					'		</table>'.
					'	</div>'.
					'	<div class="jump"><hr></div>'.
					'	<div class="jump"></div>'.
					'		<div class="infobox1" align="center">'.
					'			<br>SKILL'.
					'		</div>'.
					'		<div class="infobox" align="center">'.
					'			<br>RANGE'.
					'		</div>'.
					'		<div class="infobox4" align="center">'.
					'			<br>PRICE'.
					'		</div>'.
					'		'.
					'		'.
					'		<div class="infobox5">'.
					'			<div class="infotext" align="center">'.
					'				<p class="itext">';
					echo $srp[0];
					echo '</p>'.
						'			</div>'.
						'		</div>'.
						'		<div class="infobox2">'.
						'			<div class="infotext" align="center">'.
						'				<p class="itext">';
					echo $srp[1];
					echo '</p>'.
						'			</div>'.
						'		</div>'.
						'		<div class="infobox8">'.
						'			<div class="infotext" align="center">'.
						'				<p class="itext">';
					echo "$".$srp[2];
					echo "</p></div></div>";
					echo '<div class="jump"></div>'.
						'	'.
						'	<div class="specialbox" align="center">'.
						'		<div class="jump"></div><a>SPECIAL</a>'.
						'	</div>'.
						''.
						'	<div class="specialbox1">'.
						'		<div class="lastbit" align="center">';
					$specials = specials($id);
					
					//echo count($specials);
					
						echo "-";
						foreach($specials as $special){
							echo $special[0]." ".$special[1].", ";
						}
						echo "-";
					
					echo "</div></div></div>";
				
				
			}
			?>