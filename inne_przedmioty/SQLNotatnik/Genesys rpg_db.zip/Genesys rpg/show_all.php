<?php
$db = new mysqli("localhost","root","","genesys");
			$result = $db->query("Select item_id as id from item;");
			//$result = $db->query("Select item_id as id from item ORDER BY item.Name ASC;");
			mysqli_close($db);
			
			while($row=$result->fetch_assoc()){
				drawWeaponCard($row["id"]);
			}
			
			
?>